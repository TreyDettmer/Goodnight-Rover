﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Mono.Security.ASN1::.ctor(System.Byte)
extern void ASN1__ctor_m6DD2E5BD0B12A6BFA95E1822A55B2294B8C237BC (void);
// 0x00000002 System.Void Mono.Security.ASN1::.ctor(System.Byte,System.Byte[])
extern void ASN1__ctor_mAB2593792CB61AD1542F4F9D6FB6E8BB96DE007E (void);
// 0x00000003 System.Void Mono.Security.ASN1::.ctor(System.Byte[])
extern void ASN1__ctor_mE005F52336402C3D41EAD9E28A95910B3C0865DA (void);
// 0x00000004 System.Int32 Mono.Security.ASN1::get_Count()
extern void ASN1_get_Count_m5A0E71B4C4A2257C0875AE1041AAA953C5B12A19 (void);
// 0x00000005 System.Byte Mono.Security.ASN1::get_Tag()
extern void ASN1_get_Tag_m1346989AC839D85A9E0A211525A6B551974E4862 (void);
// 0x00000006 System.Byte[] Mono.Security.ASN1::get_Value()
extern void ASN1_get_Value_m9BD6239E12A6148AF9507C2F58058C6B8147A079 (void);
// 0x00000007 System.Void Mono.Security.ASN1::set_Value(System.Byte[])
extern void ASN1_set_Value_m225FF9AC03EA872809C7742070A34A264C58588E (void);
// 0x00000008 Mono.Security.ASN1 Mono.Security.ASN1::Add(Mono.Security.ASN1)
extern void ASN1_Add_mF6ED0416BB021A1C333F99E42F8B17AF8B26639B (void);
// 0x00000009 System.Byte[] Mono.Security.ASN1::GetBytes()
extern void ASN1_GetBytes_m4ABC0EF4CBE8CF6BE65CEC52CDB02BB59E2E9AE4 (void);
// 0x0000000A System.Void Mono.Security.ASN1::Decode(System.Byte[],System.Int32&,System.Int32)
extern void ASN1_Decode_m94E3A6F94EDACE796521D04E6A832D99592F1149 (void);
// 0x0000000B System.Void Mono.Security.ASN1::DecodeTLV(System.Byte[],System.Int32&,System.Byte&,System.Int32&,System.Byte[]&)
extern void ASN1_DecodeTLV_m30440B1DE0A8C4236AA9658DEBF2808FD3BC00C3 (void);
// 0x0000000C Mono.Security.ASN1 Mono.Security.ASN1::get_Item(System.Int32)
extern void ASN1_get_Item_m88B75C57A7E130A02A709AE8FFD2E0972E71FC08 (void);
// 0x0000000D System.String Mono.Security.ASN1::ToString()
extern void ASN1_ToString_mF3953615856548F00889AD245391D09FBE782CBA (void);
// 0x0000000E Mono.Security.ASN1 Mono.Security.ASN1Convert::FromInt32(System.Int32)
extern void ASN1Convert_FromInt32_m59FF0922659B0A323026CCC0876BC33020C4FC9A (void);
// 0x0000000F System.Int32 Mono.Security.ASN1Convert::ToInt32(Mono.Security.ASN1)
extern void ASN1Convert_ToInt32_mA2A8761F965979408D46FBEB946DB59F36137A5E (void);
// 0x00000010 System.String Mono.Security.ASN1Convert::ToOid(Mono.Security.ASN1)
extern void ASN1Convert_ToOid_mFFA93B4BBEFCA8E4E86DAE87CDB998E78BFB2D5A (void);
// 0x00000011 System.Byte[] Mono.Security.BitConverterLE::GetUIntBytes(System.Byte*)
extern void BitConverterLE_GetUIntBytes_m871281C3039A5B7DFB56E0F3EBBE22F74135997C (void);
// 0x00000012 System.Byte[] Mono.Security.BitConverterLE::GetBytes(System.Int32)
extern void BitConverterLE_GetBytes_m1207548B6BC0E2D49DD06D5B3A3AC19C001BDB35 (void);
// 0x00000013 System.String Mono.Security.Cryptography.CryptoConvert::ToHex(System.Byte[])
extern void CryptoConvert_ToHex_m2FB6183AFF3B31424407BB7D767A844E3464B411 (void);
static Il2CppMethodPointer s_methodPointers[19] = 
{
	ASN1__ctor_m6DD2E5BD0B12A6BFA95E1822A55B2294B8C237BC,
	ASN1__ctor_mAB2593792CB61AD1542F4F9D6FB6E8BB96DE007E,
	ASN1__ctor_mE005F52336402C3D41EAD9E28A95910B3C0865DA,
	ASN1_get_Count_m5A0E71B4C4A2257C0875AE1041AAA953C5B12A19,
	ASN1_get_Tag_m1346989AC839D85A9E0A211525A6B551974E4862,
	ASN1_get_Value_m9BD6239E12A6148AF9507C2F58058C6B8147A079,
	ASN1_set_Value_m225FF9AC03EA872809C7742070A34A264C58588E,
	ASN1_Add_mF6ED0416BB021A1C333F99E42F8B17AF8B26639B,
	ASN1_GetBytes_m4ABC0EF4CBE8CF6BE65CEC52CDB02BB59E2E9AE4,
	ASN1_Decode_m94E3A6F94EDACE796521D04E6A832D99592F1149,
	ASN1_DecodeTLV_m30440B1DE0A8C4236AA9658DEBF2808FD3BC00C3,
	ASN1_get_Item_m88B75C57A7E130A02A709AE8FFD2E0972E71FC08,
	ASN1_ToString_mF3953615856548F00889AD245391D09FBE782CBA,
	ASN1Convert_FromInt32_m59FF0922659B0A323026CCC0876BC33020C4FC9A,
	ASN1Convert_ToInt32_mA2A8761F965979408D46FBEB946DB59F36137A5E,
	ASN1Convert_ToOid_mFFA93B4BBEFCA8E4E86DAE87CDB998E78BFB2D5A,
	BitConverterLE_GetUIntBytes_m871281C3039A5B7DFB56E0F3EBBE22F74135997C,
	BitConverterLE_GetBytes_m1207548B6BC0E2D49DD06D5B3A3AC19C001BDB35,
	CryptoConvert_ToHex_m2FB6183AFF3B31424407BB7D767A844E3464B411,
};
static const int32_t s_InvokerIndices[19] = 
{
	31,
	1012,
	26,
	10,
	114,
	14,
	26,
	28,
	14,
	1013,
	1014,
	34,
	14,
	43,
	95,
	0,
	88,
	43,
	0,
};
extern const Il2CppCodeGenModule g_Mono_SecurityCodeGenModule;
const Il2CppCodeGenModule g_Mono_SecurityCodeGenModule = 
{
	"Mono.Security.dll",
	19,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
