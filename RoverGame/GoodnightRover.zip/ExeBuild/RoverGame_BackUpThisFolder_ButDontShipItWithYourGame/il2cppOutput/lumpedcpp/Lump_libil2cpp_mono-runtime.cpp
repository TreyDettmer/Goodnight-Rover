#include "il2cpp-config.h"
#include "C:\Program Files\Unity\Hub\Editor\2019.4.12f1\Editor\Data\il2cpp\libil2cpp\mono-runtime\il2cpp-callbacks.cpp"
#include "C:\Program Files\Unity\Hub\Editor\2019.4.12f1\Editor\Data\il2cpp\libil2cpp\mono-runtime\il2cpp-mono-support.cpp"
